#include "service.h"

Service::Service()
{
    this->repo = new Repo();
}

Service::~Service()
{
    delete this->repo;
}

std::vector<Bill> Service::getAll()
{
    return this->repo->getBills();
}

std::vector<Bill> Service::getPaid()
{
    std::vector<Bill> allBills = this->repo->getBills();
    std::vector<Bill> paidBills;

    for (Bill bill : allBills)
    {
        if (bill.getIsPaid())
        {
            paidBills.push_back(bill);
        }
    }

    return paidBills;
}

std::vector<Bill> Service::getNotPaid()
{
    std::vector<Bill> allBills = this->repo->getBills();
    std::vector<Bill> notPaidBills;

    for (Bill bill : allBills)
    {
        if (!bill.getIsPaid())
        {
            notPaidBills.push_back(bill);
        }
    }

    return notPaidBills;
}

float Service::getTotalUnpaid(std::string company)
{
    std::vector<Bill> allBills = this->repo->getBills();
    float totalUnpaid = 0;
    bool found = false;
    for (Bill bill : allBills)
    {
        if (bill.getCompany() == company && !bill.getIsPaid())
        {
            found = true;
            totalUnpaid += bill.getAmount();
        }
    }

    if (!found)
    {
        return -1;
    }

    return totalUnpaid;
}