#pragma once

#include <string>

class Bill
{
private:
    std::string company;
    std::string serialNumber;
    float amount;
    bool isPaid;

public:
    Bill(std::string company, std::string serialNumber, float amount, bool isPaid);

    std::string getCompany();
    std::string getSerialNumber();
    float getAmount();
    bool getIsPaid();

    std::string toString();
};