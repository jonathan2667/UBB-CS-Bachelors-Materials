#include "domain.h"

Bill::Bill(std::string company, std::string serialNumber, float amount, bool isPaid)
{
    this->company = company;
    this->serialNumber = serialNumber;
    this->amount = amount;
    this->isPaid = isPaid;
}

std::string Bill::getCompany()
{
    return this->company;
}

std::string Bill::getSerialNumber()
{
    return this->serialNumber;
}

float Bill::getAmount()
{
    return this->amount;
}

bool Bill::getIsPaid()
{
    return this->isPaid;
}

std::string Bill::toString()
{
    return this->company + " " + std::to_string(this->amount);
}