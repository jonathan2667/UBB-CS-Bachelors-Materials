#pragma once

#include "repo.h"

class Service
{
private:
    Repo *repo;

public:
    Service();
    ~Service();

    std::vector<Bill> getAll();
    std::vector<Bill> getPaid();
    std::vector<Bill> getNotPaid();

    float getTotalUnpaid(std::string company);
};
