#pragma once

#include "domain.h"
#include <vector>

class Repo
{
private:
    std::vector<Bill> bills;

    void loadFromFile();

public:
    Repo();
    std::vector<Bill> getBills();
};
