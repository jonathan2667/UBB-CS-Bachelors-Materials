#include "repo.h"
#include <fstream>
#include <algorithm>
void Repo::loadFromFile()
{
    std::ifstream file("bills.txt");
    std::string company;
    std::string serialNumber;
    float amount;
    bool isPaid;

    std::string line;

    while (std::getline(file, line))
    {
        std::string token;
        std::vector<std::string> tokens;

        for (int i = 0; i < line.size(); i++)
        {
            if (line[i] == ';')
            {
                tokens.push_back(token);
                token = "";
                i++;
            }
            else
            {
                token += line[i];
            }
        }

        tokens.push_back(token);

        company = tokens[0];
        serialNumber = tokens[1];
        amount = std::stof(tokens[2]);
        isPaid = tokens[3] == "true" ? true : false;

        Bill bill(company, serialNumber, amount, isPaid);
        this->bills.push_back(bill);
    }

    std::sort(this->bills.begin(), this->bills.end(), [](Bill a, Bill b)
              { return a.getCompany() < b.getCompany(); });

    file.close();
}

Repo::Repo()
{
    this->loadFromFile();
}

std::vector<Bill> Repo::getBills()
{
    return this->bills;
}