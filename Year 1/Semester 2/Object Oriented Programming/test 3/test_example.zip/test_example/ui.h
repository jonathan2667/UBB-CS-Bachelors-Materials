#pragma once

#include "service.h"
#include <QWidget>
#include <QListWidget>
#include <QVBoxLayout>
#include <QCheckBox>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
class QtUI : public QWidget
{
private:
    Service *service = new Service();

    QListWidget *billList = new QListWidget();
    QVBoxLayout *layout = new QVBoxLayout();
    QPushButton *getAllButton = new QPushButton("Get all");
    QCheckBox *isPaidCheckBox = new QCheckBox("Is paid");
    QCheckBox *isNotPaidCheckBox = new QCheckBox("Is not paid");
    QLabel *companyLabel = new QLabel("Company: ");
    QLineEdit *companyLineEdit = new QLineEdit();
    QPushButton *calculateTotalButton = new QPushButton("Calculate total");
    QLabel *totalLabel = new QLabel("Unpaid bills total: ");
    QLineEdit *total = new QLineEdit();

    std::vector<QListWidgetItem *> items;

    void populateList(std::vector<Bill> bills)
    {
        std::sort(bills.begin(), bills.end(), [](Bill a, Bill b)
                  { return a.getCompany() < b.getCompany(); });
        for (Bill bill : bills)
        {
            QListWidgetItem *item = new QListWidgetItem(QString::fromStdString(bill.toString()));

            bool isPaid = bill.getIsPaid();

            if (!isPaid)
            {
                item->setBackground(QBrush(QColor(255, 0, 0)));
            }

            this->items.push_back(item);
            this->billList->addItem(item);
        }
    }

public:
    QtUI()
    {
        std::vector<Bill> bills = this->service->getAll();

        this->populateList(bills);

        QObject::connect(isPaidCheckBox, &QCheckBox::stateChanged, [=](int state)
                         {
            if (state == Qt::Checked)
            {
                this->isNotPaidCheckBox->setChecked(false);
                std::vector<Bill> paidBills = this->service->getPaid();
                this->billList->clear();
                this->populateList(paidBills);
            }
            else
            {
                std::vector<Bill> bills = this->service->getAll();
                this->billList->clear();
                this->populateList(bills);
            
            } });

        QObject::connect(isNotPaidCheckBox, &QCheckBox::stateChanged, [=](int state)
                         {
            if (state == Qt::Checked)
            {
                this->isPaidCheckBox->setChecked(false);
                std::vector<Bill> notPaidBills = this->service->getNotPaid();
                this->billList->clear();
                this->populateList(notPaidBills);
            }
            else
            {
                std::vector<Bill> bills = this->service->getAll();
                this->billList->clear();
                this->populateList(bills);
            
            } });

        QObject::connect(this->getAllButton, &QPushButton::clicked, [=]()
                         {
                             isPaidCheckBox->setChecked(false);
                             isNotPaidCheckBox->setChecked(false);
                             std::vector<Bill> bills = this->service->getAll();
                             this->billList->clear();
                             this->populateList(bills); });

        QObject::connect(this->calculateTotalButton, &QPushButton::clicked, [=]()
                         {
                                std::string company = this->companyLineEdit->text().toStdString();
                                float totalUnpaid = this->service->getTotalUnpaid(company);
                                if (totalUnpaid == -1)
                                {
                                    this->total->setText("Invalid company!");
                                    return;
                                }
                                this->total->setText(QString::number(totalUnpaid)); });

        this->layout->addWidget(isNotPaidCheckBox);
        this->layout->addWidget(isPaidCheckBox);
        this->layout->addWidget(this->billList);
        this->layout->addWidget(this->getAllButton);

        this->layout->addWidget(this->companyLabel);
        this->layout->addWidget(this->companyLineEdit);
        this->layout->addWidget(this->calculateTotalButton);
        this->layout->addWidget(this->totalLabel);

        this->total->setReadOnly(true);
        this->layout->addWidget(this->total);

        this->setLayout(layout);
        this->show();
    }
};