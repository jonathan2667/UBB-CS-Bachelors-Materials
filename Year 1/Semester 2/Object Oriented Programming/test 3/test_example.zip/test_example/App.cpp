#include "ui.h"
#include <QApplication>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QtUI ui;

    return a.exec();
}